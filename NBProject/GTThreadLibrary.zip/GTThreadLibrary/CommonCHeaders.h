/* 
 * File:   CommonCHeaders.h
 * Author: machiry
 *
 * Created on October 31, 2011, 6:26 PM
 */

#ifndef COMMONCHEADERS_H
#define	COMMONCHEADERS_H

#define null NULL

#ifdef	__cplusplus
extern "C" {
#endif
#include <stdio.h>
#include <ucontext.h>
#include <signal.h>
#include <sys/time.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

#ifdef	__cplusplus
}
#endif

#endif	/* COMMONCHEADERS_H */

