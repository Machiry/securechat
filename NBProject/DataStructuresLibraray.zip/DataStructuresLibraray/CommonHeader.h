/* 
 * File:   CommonHeader.h
 * Author: machiry
 *
 * Created on November 28, 2011, 12:42 PM
 */

#ifndef COMMONHEADER_H
#define	COMMONHEADER_H

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<malloc.h>
#define null NULL



#endif	/* COMMONHEADER_H */

